export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      projects: {
        Row: {
          id: string
          owner_id: string
          name: string
          created_at: string
        }
        Insert: {
          id?: string
          owner_id: string
          name: string
          created_at?: string
        }
        Update: {
          id?: string
          owner_id?: string
          name?: string
          created_at?: string
        }
        Relationships: []
      }
      script_auth_tokens: {
        Row: {
          created_at: string
          expires_at: string
          hwid: string | null
          id: string
          key_id: string | null
          script_id: string
          token: string
          used: boolean
        }
        Insert: {
          created_at?: string
          expires_at: string
          hwid?: string | null
          id?: string
          key_id?: string | null
          script_id: string
          token: string
          used?: boolean
        }
        Update: {
          created_at?: string
          expires_at?: string
          hwid?: string | null
          id?: string
          key_id?: string | null
          script_id?: string
          token?: string
          used?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "script_auth_tokens_key_id_fkey"
            columns: ["key_id"]
            isOneToOne: false
            referencedRelation: "script_keys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "script_auth_tokens_script_id_fkey"
            columns: ["script_id"]
            isOneToOne: false
            referencedRelation: "scripts"
            referencedColumns: ["id"]
          },
        ]
      }
      script_keys: {
        Row: {
          auto_reset_hwid: boolean
          created_at: string
          format: string
          hwid: string | null
          id: string
          key: string
          label: string
          last_used: string | null
          script_id: string
        }
        Insert: {
          auto_reset_hwid?: boolean
          created_at?: string
          format?: string
          hwid?: string | null
          id?: string
          key: string
          label?: string
          last_used?: string | null
          script_id: string
        }
        Update: {
          auto_reset_hwid?: boolean
          created_at?: string
          format?: string
          hwid?: string | null
          id?: string
          key?: string
          label?: string
          last_used?: string | null
          script_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "script_keys_script_id_fkey"
            columns: ["script_id"]
            isOneToOne: false
            referencedRelation: "scripts"
            referencedColumns: ["id"]
          },
        ]
      }
      script_users: {
        Row: {
          blacklist_message: string
          blacklisted: boolean
          created_at: string
          display_name: string | null
          game_name: string | null
          id: string
          last_seen: string
          menu_json: string
          pending_effect_message: string
          pending_effect_type: string
          place_id: number | null
          script_id: string
          user_key: string
        }
        Insert: {
          blacklist_message?: string
          blacklisted?: boolean
          created_at?: string
          display_name?: string | null
          game_name?: string | null
          id?: string
          last_seen?: string
          menu_json?: string
          pending_effect_message?: string
          pending_effect_type?: string
          place_id?: number | null
          script_id: string
          user_key: string
        }
        Update: {
          blacklist_message?: string
          blacklisted?: boolean
          created_at?: string
          display_name?: string | null
          game_name?: string | null
          id?: string
          last_seen?: string
          menu_json?: string
          pending_effect_message?: string
          pending_effect_type?: string
          place_id?: number | null
          script_id?: string
          user_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "script_users_script_id_fkey"
            columns: ["script_id"]
            isOneToOne: false
            referencedRelation: "scripts"
            referencedColumns: ["id"]
          },
        ]
      }
      scripts: {
        Row: {
          created_at: string
          deleted: boolean
          effect_message: string
          effect_type: string
          encoded: string
          id: string
          name: string | null
          original_size: number
          slug: string
          version: number
          owner_id: string | null
          project_id: string | null
          pastefy_id: string | null
          pastefy_url: string | null
        }
        Insert: {
          created_at?: string
          deleted?: boolean
          effect_message?: string
          effect_type?: string
          encoded: string
          id?: string
          name?: string | null
          original_size?: number
          slug: string
          version?: number
          owner_id?: string | null
          project_id?: string | null
          pastefy_id?: string | null
          pastefy_url?: string | null
        }
        Update: {
          created_at?: string
          deleted?: boolean
          effect_message?: string
          effect_type?: string
          encoded?: string
          id?: string
          name?: string | null
          original_size?: number
          slug?: string
          version?: number
          owner_id?: string | null
          project_id?: string | null
          pastefy_id?: string | null
          pastefy_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
